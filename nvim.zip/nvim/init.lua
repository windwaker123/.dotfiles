-- =========================================
-- LazyVim + Snacks.nvim Doom Dashboard + Catppuccin Acrylic (using your plugin opts)
-- =========================================

-- Load lazy.nvim
vim.opt.rtp:prepend(vim.fn.stdpath('data') .. '/lazy/lazy.nvim')

-- =========================
-- Load plugins
-- =========================
require('lazy').setup({
  -- Snacks.nvim for Doom-style dashboard
  {
    "folke/snacks.nvim",
    lazy = false,
    priority = 1000,
    opts = {
      dashboard = {
        enabled = true,
        preset = {
          header = [[
 ███╗   ██╗ ██████╗ ██╗     ██╗
 ████╗  ██║██╔═══██╗██║     ██║
 ██╔██╗ ██║██║   ██║██║     ██║
 ██║╚██╗██║██║   ██║██║     ██║
 ██║ ╚████║╚██████╔╝███████╗██║
 ╚═╝  ╚═══╝ ╚═════╝ ╚═╝
          ]],
          keys = {
            { key = "f", desc = "Find files", action = "Telescope find_files" },
            { key = "r", desc = "Recent files", action = "Telescope oldfiles" },
            { key = "n", desc = "New file", action = "enew" },
            { key = "q", desc = "Quit Neovim", action = "quit" },
          },
        },
      },
    },
    dependencies = {
      "nvim-tree/nvim-web-devicons",
      "nvim-telescope/telescope.nvim",
    },
  },

  -- Catppuccin plugin with transparency
  {
    "catppuccin/nvim",
    opts = {
      transparent_background = true,
      float = {
        transparent = true,
        solid = true,
      },
    },
  },

  -- LazyVim itself: set colorscheme to Catppuccin
  {
    "LazyVim/LazyVim",
    opts = {
      colorscheme = "catppuccin",
    },
  },

  -- Disable scrollbar plugins to remove extra scroll decorations
  { "petertriho/nvim-scrollbar", enabled = false },
  { "echasnovski/mini.indentscope", enabled = false },
})

-- =========================
-- Force Acrylic / Transparent Highlights after everything loads
-- =========================
vim.api.nvim_create_autocmd("VimEnter", {
  callback = function()
    vim.cmd [[
      " Main background
      hi Normal guibg=NONE
      hi NormalNC guibg=NONE

      " Vertical splits & statusline
      hi VertSplit guibg=NONE
      hi StatusLine guibg=NONE

      " Line numbers & sign column
      hi LineNr guibg=NONE
      hi SignColumn guibg=NONE
      vim.o.signcolumn = "yes"  " keep width

      " Floating windows & borders
      hi FloatBorder guibg=NONE
      hi Pmenu guibg=NONE
      hi TelescopePromptNormal guibg=NONE
      hi TelescopeResultsNormal guibg=NONE
      hi TelescopePreviewNormal guibg=NONE

      " Dashboard (Snacks.nvim) transparent
      hi DashboardHeader guibg=NONE
      hi DashboardCenter guibg=NONE
      hi DashboardFooter guibg=NONE

      " Cursor line
      hi CursorLine guibg=NONE
    ]]
  end
})