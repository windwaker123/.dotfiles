return {
  -- Snacks.nvim (includes dashboard)
  {
    "folke/snacks.nvim",
    lazy = false,     -- load immediately
    priority = 1000,  -- early load
    opts = {
      dashboard = {
        enabled = true,
        -- Use the "preset" fields to build a doom-style dashboard
        preset = {
          header = [[
 ███╗   ██╗ ██████╗ ██╗     ██╗
 ████╗  ██║██╔═══██╗██║     ██║
 ██╔██╗ ██║██║   ██║██║     ██║
 ██║╚██╗██║██║   ██║██║     ██║
 ██║ ╚████║╚██████╔╝███████╗██║
 ╚═╝  ╚═══╝ ╚═════╝ ╚══════╝╚═╝
          ]],
          keys = {
            { key = "f", desc = "Find files", action = "Telescope find_files" },
            { key = "r", desc = "Recent files", action = "Telescope oldfiles" },
            { key = "n", desc = "New file", action = "enew" },
            { key = "q", desc = "Quit Neovim", action = "quit" },
          },
        },
      },
    },
    dependencies = {
      "nvim-tree/nvim-web-devicons",   -- for icons
      "nvim-telescope/telescope.nvim", -- for the find-files keys
    },
  },
}